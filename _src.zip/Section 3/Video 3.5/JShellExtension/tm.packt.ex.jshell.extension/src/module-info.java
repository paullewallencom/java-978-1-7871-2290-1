module tm.packt.ex.jshell.extension {

    requires jdk.jshell;
}