/*
 * Author:  Mohamed Taman, 27/5/2018
 * Course:  Hands-On Java 10 Programming with JShell
 * 		    By Packt Publisher
 * section: Interactive Java Shell 10, Basics
 * Video:   1.3 examples - Welcome to JShell
*/
public class Welcome {
   // main method begins execution of Java application”
 public static void main(String[] args) {
      System.out.println("Welcome to Java 10 Programming!");
   } // end method main
} // end class Welcome
